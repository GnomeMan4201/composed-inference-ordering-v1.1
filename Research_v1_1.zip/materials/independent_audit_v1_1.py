#!/usr/bin/env python3
# Read-only v1.1 experiment audit | Python 3.9+ | stdlib only | [a-Shell ok] [Linux ok]
"""Independently check the frozen results ZIP; write only derived analysis files.

No network, credentials, subprocesses, or modifications to source archive.
"""
import argparse
import collections
import csv
import hashlib
import json
import pathlib
import re
import sys
import zipfile

EXPECTED = {
    'manifest.json': 'f44ef832854c609cff00199e7ffdd4aabd49aab31faac3e0f183a107e5a26632',
    'prompts.jsonl': '56bca0f422cb30440a77692d3f1abc6c6331f528a57b212071eba66e9456b671',
    'model_raw.jsonl': '888d9e94b3e36379b175e51d7fcf602d1e31b0b15221026e09de9fc4aa897cab',
    'events.jsonl': '983590dc9cb85d16cca78447d680a51311e8bbdb58663bb8e80d0e17e8a1631d',
    'report_gpt-4.1-mini.json': '4b9c4849f03293244c11f4e112a80a6c3cbc1651974005130315733097cfb043',
    'evidence_inference_pilot_v1_1.py': 'ff196d55c0033059ea89b4f5c61e9ec24486b6d7fa6cbe3f47188a11b514cde5',
    'EXPERIMENT_PROTOCOL_v1_1.md': '8495874b87aac58cfcdaab2bebef2229d384c6494727f8247c25dd88a45d3936',
}
MODEL = 'gpt-4.1-mini'
ACTUAL_MODEL = 'gpt-4.1-mini-2025-04-14'
TASKS = ('extract', 'judge', 'audit')
CONDITIONS = ('baseline', 'evidence_reverse', 'paragraph_reverse')
GOLDS = {'shared-host':'NOT_ESTABLISHED', 'same-owner-control':'SUPPORTED',
         'temporal-leap':'NOT_ESTABLISHED','direct-coordination-control':'SUPPORTED'}
VERDICTS = ('SUPPORTED','NOT_ESTABLISHED','ABSTAIN')
RELATIONS = ('COORDINATION','COPYING','COMMON_OPERATOR','NONE','OTHER')
FENCE = re.compile(r'^```(?:json)?[ \t]*\r?\n(.*?)\r?\n```$',re.S|re.I)


def require(p, msg):
    if not p:
        raise ValueError(msg)


def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',', ':'),ensure_ascii=False)


def digest(x):
    return hashlib.sha256(canonical(x).encode()).hexdigest()


def read_jsonl(blob):
    return [json.loads(x) for x in blob.decode().splitlines() if x.strip()]


def normalized(task,r):
    s=r['response_text'].strip()
    val=r.get('parsed')
    kind='strict'
    if val is None:
        m=FENCE.fullmatch(s)
        kind='fenced' if m else 'unrecoverable'
        if m:
            try: val=json.loads(m.group(1))
            except ValueError: kind='unrecoverable'
    def valid(v):
        if not isinstance(v,dict):return False
        if task=='judge':return v.get('verdict') in VERDICTS and isinstance(v.get('explanation'),str)
        if task=='extract':return v.get('relation') in RELATIONS and isinstance(v.get('implied_claim'),str)
        return (v.get('relation') in RELATIONS and v.get('verdict') in VERDICTS
                and isinstance(v.get('implied_claim'),str) and isinstance(v.get('explanation'),str))
    if not valid(val):kind='unrecoverable'
    return kind, val if valid(val) else None


def reconstruct_prompt(t,task, instructions):
    evidence='\n'.join(f'{i+1}. {s}' for i,s in enumerate(t['evidence']))
    paragraph=' '.join(t['paragraph_sentences'])
    if task=='extract':body='Composed paragraph:\n'+paragraph
    else:
        body='Stipulated evidence:\n'+evidence+'\n\nComposed paragraph (not additional evidence):\n'+paragraph
        if task=='judge':body+='\n\nConclusion to evaluate:\n'+t['candidate']
    return dict(trial_id=t['trial_id'],case_id=t['case_id'],condition=t['condition'],
                task=task,instructions=instructions[task],input=body)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--archive',required=True,help='Original evidence_inference_results_v1_1.zip')
    ap.add_argument('--out',default='independent_audit_output',help='Directory for derived analysis only')
    args=ap.parse_args()
    with zipfile.ZipFile(args.archive) as z:
        require(z.testzip() is None,'ZIP CRC failed')
        blobs={n:z.read(n) for n in z.namelist()}
    require(len(blobs)==10 and all('/' not in n and n not in ('.','..') for n in blobs),'Unexpected ZIP structure')
    checks={n:{'expected':v,'actual':hashlib.sha256(blobs[n]).hexdigest()} for n,v in EXPECTED.items()}
    for n,c in checks.items():require(c['expected']==c['actual'],'Unexpected SHA-256 for '+n)
    for n in ('model_raw.jsonl','events.jsonl'):
        require(re.search(rb'\bBearer\s+sk-[\w-]+',blobs[n],re.I) is None,'Potential credential in '+n)
    manifest=json.loads(blobs['manifest.json']); prompts=read_jsonl(blobs['prompts.jsonl'])
    rows=read_jsonl(blobs['model_raw.jsonl']); events=read_jsonl(blobs['events.jsonl'])
    official=json.loads(blobs['report_gpt-4.1-mini.json'])
    require(digest(manifest)=='114ab37edfcd055932fb2e5ad34d9c5ee8623a4e16fafab0e15f82f7601326dd','Manifest digest mismatch')
    require(manifest['script_sha256']==checks['evidence_inference_pilot_v1_1.py']['actual'],'Manifest script SHA mismatch')
    require(len(manifest['trials'])==12 and len(prompts)==36,'Unexpected number of trials/prompts')
    require(set(t['case_id'] for t in manifest['trials'])==set(GOLDS),'Unexpected cases')
    trial_by_id={t['trial_id']:t for t in manifest['trials']}
    require(len(trial_by_id)==12,'Duplicate trial identifiers')
    for case in GOLDS:
        tc=[t for t in manifest['trials'] if t['case_id']==case]
        require(set(t['condition'] for t in tc)==set(CONDITIONS),'Missing condition for '+case)
        base=next(t for t in tc if t['condition']=='baseline')
        for t in tc:
            require(t['gold']==GOLDS[case],'Gold mismatch')
            require(sorted(t['evidence'])==sorted(base['evidence']),'Evidence content changed')
            require(sorted(t['paragraph_sentences'])==sorted(base['paragraph_sentences']),'Paragraph content changed')
            require(t['candidate']==base['candidate'],'Candidate changed')
    expected_prompts=[reconstruct_prompt(t,task,manifest['instructions']) for t in manifest['trials'] for task in TASKS]
    require(prompts==expected_prompts,'Frozen prompt entries mismatch independently reconstructed prompts')
    prompt_by_pair={(p['trial_id'],p['task']):p for p in prompts}
    require(len(prompt_by_pair)==36,'Duplicate prompts')
    starts={}; finishes={}
    for e in events:
        require(e.get('manifest_sha256')==digest(manifest) and e.get('model')==MODEL,'Event context mismatch')
        uid=e['attempt_id']
        if e['event']=='start':require(uid not in starts,'Duplicate start');starts[uid]=e
        elif e['event']=='finish': require(uid not in finishes,'Duplicate finish');finishes[uid]=e
        else:raise ValueError('Unexpected event')
    require(len(starts)==37 and len(finishes)==37 and set(starts)==set(finishes),'Event count/pair mismatch')
    require(len(rows)==37,'Unexpected response/failed attempt count')
    attempts={}; success={}; failures=[]; observed_models=collections.Counter()
    formats=collections.Counter(); by_task=collections.Counter(); score={'strict':{'judge_matching':0,'judge_mismatching':0,'judge_abstaining':0},'normalized':{'judge_matching':0,'judge_mismatching':0,'judge_abstaining':0}}
    output_rows=[]
    for r in rows:
        uid=r['attempt_id']; pair=(r['trial_id'],r['task'])
        require(uid not in attempts and uid in starts and uid in finishes,'Attempt chain mismatch')
        require(pair in prompt_by_pair,'Unknown trial/task')
        require(all(x.get('trial_id')==pair[0] and x.get('task')==pair[1] for x in (starts[uid],finishes[uid])),'Event trial/task mismatch')
        require(r['prompt_sha256']==digest(prompt_by_pair[pair]),'Prompt hash mismatch')
        require(r.get('manifest_sha256')==digest(manifest) and r.get('model')==MODEL,'Raw model/context mismatch')
        require(finishes[uid]['status']==r['status'],'Event raw status mismatch')
        attempts[uid]=r
        if r['status']!='ok':
            failures.append({'trial_id':pair[0],'task':pair[1],'attempt_id':uid,'status':r['status'],'http_status':r.get('http_status')});continue
        require(pair not in success,'Duplicate success for trial/task')
        require(r['raw_response'].get('status')=='completed','Noncomplete API result recorded ok')
        observed_models[r['raw_response'].get('model')]+=1
        kind,value=normalized(pair[1],r)
        if r.get('parsed') is not None:require(value==r['parsed'],'Frozen parsed field differs')
        formats[kind]+=1;by_task[pair[1]]+=1
        require(value is not None,'Unrecoverable response format')
        success[pair]=(kind,value,r)
        if pair[1]=='judge':
            for interpretation in ('normalized',)+(('strict',) if kind=='strict' else ()):
                verdict=value['verdict'];gold=trial_by_id[pair[0]]['gold']
                if verdict=='ABSTAIN': score[interpretation]['judge_abstaining']+=1
                elif verdict==gold:score[interpretation]['judge_matching']+=1
                else:score[interpretation]['judge_mismatching']+=1
        output_rows.append({'trial_id':pair[0], 'case_id':trial_by_id[pair[0]]['case_id'],
          'condition':trial_by_id[pair[0]]['condition'],'task':pair[1], 'format':kind,
          'relation':value.get('relation',''),'verdict':value.get('verdict',''),
          'author_gold':trial_by_id[pair[0]]['gold'],'implied_claim':value.get('implied_claim',''),
          'attempt_id':uid,'prompt_sha256':r['prompt_sha256'],
          'response_id':r['raw_response'].get('id',''), 'actual_model':r['raw_response'].get('model','')})
    require(len(success)==36 and len(failures)==1 and failures[0]['http_status']==429,'Expected 36 successes and one HTTP 429')
    require(observed_models=={ACTUAL_MODEL:36},'Multiple/unexpected returned model versions')
    require(formats=={'strict':19,'fenced':17},'Format count mismatch')
    require(score['strict']=={'judge_matching':6,'judge_mismatching':0,'judge_abstaining':0},'Strict judge score mismatch')
    require(official['valid_formatted_responses']==19 and official['invalid_format']==17 and official['explicit_judge_correct']==6,'Official report mismatch')
    percase=[]
    for case in GOLDS:
        record={'case_id':case,'author_gold':GOLDS[case]}
        for condition in CONDITIONS:
            for task in TASKS:
                kind,v,r=success[(case+':'+condition,task)]
                record[f'{task}_{condition}']=v.get('verdict') or v.get('relation')
                record[f'{task}_{condition}_format']=kind
        percase.append(record)
    flips={}
    for task in ('judge','audit','extract'):
        for condition in ('evidence_reverse','paragraph_reverse'):
            valid_frozen=changed_frozen=changed_normalized=0
            for case in GOLDS:
                before=success[(case+':baseline',task)];after=success[(case+':'+condition,task)]
                fld='relation' if task=='extract' else 'verdict'
                if before[0]=='strict' and after[0]=='strict':
                    valid_frozen+=1;changed_frozen+=before[1][fld]!=after[1][fld]
                changed_normalized+=before[1][fld]!=after[1][fld]
            flips[f'{task}:{condition}']={'strict_comparable_pairs':valid_frozen,'strict_changed':changed_frozen,'normalized_comparable_pairs':4,'normalized_changed':changed_normalized}
    output_rows.sort(key=lambda x:(x['case_id'],CONDITIONS.index(x['condition']),TASKS.index(x['task'])))
    finding={'status':'INDEPENDENT_OFFLINE_RECONSTRUCTION','protocol':manifest['protocol'],
       'archive_sha256':hashlib.sha256(pathlib.Path(args.archive).read_bytes()).hexdigest(),
       'checked_file_hashes':checks,'manifest_canonical_sha256':digest(manifest),
       'starts':len(starts),'finishes':len(finishes),'raw_records':len(rows),
       'model_responses_completed':len(success),'failed_attempts':failures,
       'returned_model_identifiers':dict(observed_models),'format_counts':dict(formats),
       'responses_per_task':dict(by_task),'judge_scores':score,
       'flips':flips, 'case_matrix':percase,
       'strict_protocol_caveat':'Only raw JSON responses count in frozen primary score; fenced decoding is exploratory.',
       'causality_caveat':'One call per condition; differences are observational, not proven effects of ordering.',
       'gold_caveat':'Author-assigned labels not independently adjudicated.',
       'claim_caveat':'Audit evaluates a self-selected claim, which may not match judge candidate.'}
    out=pathlib.Path(args.out)
    if out.exists() and any(out.iterdir()):raise ValueError('Output directory not empty; select a fresh --out')
    out.mkdir(parents=True,exist_ok=True)
    (out/'derived_audit_v1_1.json').write_text(json.dumps(finding,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    with (out/'trial_matrix_v1_1.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(output_rows[0]));w.writeheader();w.writerows(output_rows)
    print('INDEPENDENT AUDIT PASS; no live API calls')
    print('Raw attempts:',len(rows),'completed:',len(success),'failed:',len(failures))
    print('Response format:',dict(formats))
    print('Frozen judge:',score['strict'],'exploratory normalized:',score['normalized'])
    print('Observed comparisons:',json.dumps(flips,sort_keys=True))
    print('Derived:',out/'derived_audit_v1_1.json','and',out/'trial_matrix_v1_1.csv')
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except (ValueError,KeyError,FileNotFoundError,zipfile.BadZipFile,json.JSONDecodeError) as e:
        print('AUDIT FAILED:',e,file=sys.stderr);sys.exit(3)
