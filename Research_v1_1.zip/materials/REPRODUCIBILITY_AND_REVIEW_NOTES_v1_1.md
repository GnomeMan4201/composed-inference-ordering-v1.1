# Technical audit appendix — evidence ordering v1.1

**Status:** Offline reconstruction passed; no independent outside reviewer has signed off.

## Files and integrity

Original uploaded ZIP SHA-256: `b117050aa57dd573ac8bec20211ae706a7bd957ecda60ff051a5a15b836b543e`.

Checked: ZIP CRC; hashes of script, protocol, manifest, prompts, raw results, events, original report; reconstructed all 36 exact prompts and every request's `prompt_sha256`; 37 unique attempt IDs and matching start/finish events; all 36 successful API responses' completed status and consistent returned model identifier. Original entries unchanged. Expected initial `SHA256SUMS.txt` is a *pre-run index*, not a final index: the append-only ledger hash changed, and two named initial files are not in the result ZIP.

The 17 `invalid_format` responses all begin with Markdown triple-backtick `json` and end with triple backticks. For exploratory parsing only, the opening and closing markers were removed in memory, with no replacement, editing, repair of content, or overwriting. Every enclosed object parsed and passed the script's expected task-field checks.

## Two distinct comparisons

1. **Frozen primary:** Strict response parser, author labels, exact unmodified report. Six of six evaluable explicit judge responses match author labels, six more fail formatting. One strict valid baseline-versus-paragraph reversal `audit` flip (`shared-host`); three audit pairs evaluable. No strict baseline-versus-evidence reversal audit pair is evaluable.
2. **Exploratory secondary:** Decoding of fenced JSON only; 12 of 12 `judge` verdicts match author labels; 0 of 8 explicit-judge paired comparisons flip; 1 of 8 open-audit comparisons flips. `extract` relation labels change for `same-owner-control` in 1/4 evidence reversals and 1/4 paragraph reversals, but one changed pair has identical model-facing input.

## Exact high-value source records

| Trial / task | Original format | Verdict / relation | Prompt SHA-256 | Response ID |
| --- | --- | --- | --- | --- |
| `shared-host:baseline` / `audit` | strict | `COORDINATION`, `NOT_ESTABLISHED` | `a5ac5f9340e36118231d309922bd203dee04fe21e6bec1a14d940aa061dd535f` | `resp_0a366a10e69b9bad016ae53bf2ffbc87d1aa3679b24825a901` |
| `shared-host:paragraph_reverse` / `audit` | strict | `COORDINATION`, `SUPPORTED` | `e962b3e92082ecacd4c84068ff3de67967d67afcb60d6de0662ec8f1528f7800` | `resp_0dea1141f65291c8016ae53bd5e0b087d1bd06de18b2577609` |
| `shared-host:paragraph_reverse` / `judge` | strict | `NOT_ESTABLISHED` | `ae73eec8b5adebc2d4e043670292ab04a72d91e9f24296e75f9f6e4dfbe6e5cd` | `resp_029f596c148b763e016ae53bd49a5887d185d0b20387041242` |
| `same-owner-control:baseline` / `extract` | fenced | `COMMON_OPERATOR` | `d1687d8b696dd1afbfbd50d02d8584adab0a0a27f2355ce5433c12cd9ddb2df7` | `resp_09ec0f09c0c0ba36016ae53be83bfc87d19435e4fc4dcfa3a1` |
| `same-owner-control:evidence_reverse` / `extract` | strict | `COORDINATION` | `da7983be1f91fb12fd7b8039f1057f918073f916e1e39c073d8264bd81e55f8a` | `resp_07a7a8b9d7440757016ae53bec640c87d190569514be500316` |

**Important:** This appendix is a navigation aid. Always use the exact machine-generated `trial_matrix_v1_1.csv` and original JSONL for the authoritative SHA and ID values. The copied table identifiers were checked against their original `model_raw.jsonl` records during preparation; the CSV permits a separate check.

## Reviewer questions still open

- Do independent readers agree that each paragraph actually **invites** the target implication?
- Do independent readers agree with all four author labels and the rival explanations?
- In the one shared-host flipped audit response, would the same model still endorse coordination under identical prompts across repeated trials?
- Did changing the model-facing paragraph *cause* the observed audit difference, or was it ordinary sampling/service variation?
- Should the `COORDINATION` tag be treated as a coding mistake when the claim text describes only **common operation**?
- Does sentence order alone capture the phenomenon of an implied but unstated narrative conclusion well enough to be useful?

Until those are tested, this is an exploratory record, not a detector qualification or claim of broad ordering sensitivity.
